"use client";

import { useEffect, useState } from "react";
import Image from "next/image";

export default function Home() {
  const [scrolled, setScrolled] = useState(false);

useEffect(() => {
  const handleScroll = () => {
    setScrolled(window.scrollY > 80);
  };

  window.addEventListener("scroll", handleScroll);

  return () => window.removeEventListener("scroll", handleScroll);
}, []);
  const services = [
  {
    title: "Architectural Design",
    desc: "Functional, aesthetic and innovative architectural solutions.",
    icon: "/architectural.svg",
  },
  {
    title: "Interior Design",
    desc: "Beautiful interiors tailored to your lifestyle and personality.",
    icon: "/interior.svg",
  },
  {
    title: "3D Visualization",
    desc: "High quality renders that bring your vision to life.",
    icon: "/visualization.svg",
  },
  {
    title: "House Plans",
    desc: "Bungalow, Maisonette & Mansion plans customized for you.",
    icon: "/houseplans.svg",
  },
  {
    title: "Construction Drawings",
    desc: "Accurate, detailed and build-ready drawings.",
    icon: "/drawings.svg",
  },
  {
    title: "Student Assistance",
    desc: "Academic support for architecture & design students.",
    icon: "/student.svg",
  },
];

  const projects = [
    {
      title: "Karen Maisonette",
      type: "Residential",
      image:
        "https://images.unsplash.com/photo-1600585154526-990dced4db0d",
    },
    {
      title: "Riverside Residence",
      type: "Interior Design",
      image:
        "https://images.unsplash.com/photo-1505693416388-ac5ce068fe85",
    },
    {
      title: "Eldoret Plaza",
      type: "Commercial",
      image:
        "https://images.unsplash.com/photo-1486406146926-c627a92ad1ab",
    },
  ];

  return (
    <main className="bg-[#071321] text-white">

      {/* NAVBAR */}
      <header
  className={`fixed top-0 left-0 w-full z-50 transition-all duration-500 ${
    scrolled
      ? "bg-white shadow-lg py-2"
      : "bg-transparent py-4"
  }`}
>
        <div className="max-w-7xl mx-auto flex items-center justify-between px-8 py-6">

          <div>
            <h1
  className={`text-2xl font-light tracking-[8px] ${
    scrolled ? "text-[#1c3a60]" : "text-white"
  }`}
>
              APIYO
            </h1>
            <p className="text-xs tracking-[4px] text-gray-400">
              DESIGN STUDIO
            </p>
          </div>

          <nav
  className={`hidden lg:flex gap-8 text-sm uppercase tracking-wider ${
    scrolled ? "text-[#1c3a60]" : "text-white"
  }`}
>
            <a href="#">Home</a>
            <a href="#">About</a>
            <a href="#">Services</a>
            <a href="#">Projects</a>
            <a href="#">House Plans</a>
            <a href="#">Interiors</a>
            <a href="#">Students</a>
            <a href="#">Contact</a>
          </nav>

          <button
  className={`px-6 py-3 transition border ${
    scrolled
      ? "bg-[#1c3a60] text-white border-[#1c3a60]"
      : "border-[#D4A85A] text-[#D4A85A]"
  }`}
>
            Book Consultation
          </button>
        </div>
      </header>

      {/* HERO */}
      <section
        className="relative min-h-screen flex items-center overflow-hidden"
        
     style={{
  backgroundImage: "url('/images/hero-reference.png')",
  backgroundSize: "cover",
  backgroundPosition: "center",
}}
      >
        <div className="absolute inset-0 bg-[#1c3a60]/50"></div>

        <div className="relative max-w-7xl mx-auto px-8 w-full">
          <div className="max-w-4xl">

            <p className="uppercase tracking-[4px] text-[#D4A85A] mb-5">
              Welcome To Apiyo Design Studio
            </p>

            <h1 className="text-5xl md:text-7xl lg:text-8xl font-serif leading-[1.05] mb-8 max-w-[900px]">
  Building Futures
  <br />
  Through Design.
</h1>

            <div className="w-24 h-[2px] bg-[#D4A85A] mb-8"></div>

            <p className="text-gray-300 text-lg mb-10 max-w-xl">
              Architecture. Interior Design. House Plans.
              We craft spaces that inspire, elevate lifestyles
              and stand the test of time.
            </p>

            <div className="flex flex-wrap gap-4">
              <button className="bg-[#D4A85A] text-black px-8 py-4 font-medium">
                View Our Work
              </button>

              <button className="border border-[#D4A85A] text-[#D4A85A] px-8 py-4">
                Our Services
              </button>
            </div>
          </div>
        </div>
      </section>

      {/* SERVICES */}
      <section className="py-24 bg-[#071321]">
        <div className="max-w-7xl mx-auto px-8">

          <p className="text-center uppercase tracking-[4px] text-[#D4A85A]">
            What We Do
          </p>

          <h2 className="text-center text-5xl font-serif mt-4 mb-16">
            Design. Build. Inspire.
          </h2>

          <div className="grid md:grid-cols-3 lg:grid-cols-6 gap-6">

            {services.map((service) => (
              <div
                key={service.title}
                className="border border-gray-700 p-8 text-center hover:border-[#D4A85A] transition"
              >
                <div className="flex justify-center mb-6">
  <img
    src={service.icon}
    alt={service.title}
    className="w-[70px] h-[70px] object-contain"
  />
</div>

                <h3 className="font-semibold mb-4">
                  {service.title}
                </h3>

                <p className="text-gray-400 text-sm">
                  {service.desc}
                </p>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* PROJECTS */}
      <section className="py-24">
        <div className="max-w-7xl mx-auto px-8">

          <p className="uppercase tracking-[4px] text-[#D4A85A]">
            Our Work
          </p>

          <h2 className="text-5xl font-serif mt-4 mb-14">
            Featured Projects
          </h2>

          <div className="grid lg:grid-cols-3 gap-8">

            {projects.map((project) => (
              <div
                key={project.title}
                className="group overflow-hidden border border-gray-700"
              >
                <div className="overflow-hidden">
                  <img
                    src={project.image}
                    alt={project.title}
                    className="h-[350px] w-full object-cover group-hover:scale-110 transition duration-700"
                  />
                </div>

                <div className="p-6">
                  <h3 className="text-xl mb-2">
                    {project.title}
                  </h3>

                  <p className="text-gray-400">
                    {project.type}
                  </p>
                </div>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* WHY US */}
      <section className="grid lg:grid-cols-2">

        <div
          className="min-h-[500px]"
          style={{
            backgroundImage:
              "url('https://images.unsplash.com/photo-1505693416388-ac5ce068fe85')",
            backgroundSize: "cover",
            backgroundPosition: "center",
          }}
        />

        <div className="bg-[#071321] p-16 flex flex-col justify-center">

          <p className="uppercase tracking-[4px] text-[#D4A85A]">
            Why Choose Us
          </p>

          <h2 className="text-5xl font-serif leading-tight mt-4">
            We don't just design buildings,
            we create legacies.
          </h2>

          <div className="grid grid-cols-2 gap-10 mt-16">

            <div>
              <h3 className="text-5xl text-[#D4A85A]">
                100+
              </h3>
              <p>Projects Completed</p>
            </div>

            <div>
              <h3 className="text-5xl text-[#D4A85A]">
                50+
              </h3>
              <p>Happy Clients</p>
            </div>

            <div>
              <h3 className="text-5xl text-[#D4A85A]">
                5+
              </h3>
              <p>Years Experience</p>
            </div>

            <div>
              <h3 className="text-5xl text-[#D4A85A]">
                Premium
              </h3>
              <p>Quality Delivery</p>
            </div>

          </div>
        </div>
      </section>

      {/* CTA */}
      <section className="py-20 bg-[#071321]">
        <div className="max-w-7xl mx-auto px-8 flex flex-col lg:flex-row items-center justify-between gap-10">

          <div>
            <h2 className="text-5xl font-serif mb-4">
              Let's bring your dream project to life.
            </h2>

            <p className="text-gray-300">
              Book a consultation and take the first step today.
            </p>
          </div>

          <button className="bg-[#D4A85A] text-black px-10 py-5">
            Book Consultation
          </button>

        </div>
      </section>

      {/* FOOTER */}
      <footer className="bg-[#071321] py-16 border-t border-[#D4A85A]/20">
        <div className="max-w-7xl mx-auto px-8 grid md:grid-cols-4 gap-10">

          <div>
            <h3 className="text-3xl mb-4">
              APIYO
            </h3>

            <p className="text-gray-400">
              Building Futures Through Design.
            </p>
          </div>

          <div>
            <h4 className="mb-4 font-semibold">
              Quick Links
            </h4>

            <ul className="space-y-2 text-gray-400">
              <li>About</li>
              <li>Services</li>
              <li>Projects</li>
              <li>House Plans</li>
            </ul>
          </div>

          <div>
            <h4 className="mb-4 font-semibold">
              Contact
            </h4>

            <p className="text-gray-400">
              +254 700 000 000
            </p>

            <p className="text-gray-400">
              info@apiyodesignstudio.co.ke
            </p>
          </div>

          <div>
            <h4 className="mb-4 font-semibold">
              Location
            </h4>

            <p className="text-gray-400">
              Nairobi, Kenya
            </p>
          </div>

        </div>
      </footer>

    </main>
  );
}